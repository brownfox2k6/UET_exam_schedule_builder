#include "aco/ant_colony.hpp"
#include "common/room.hpp"
#include "utils/assert.hpp"

#include <cstddef>
#include <pybind11/gil.h>
#include <pybind11/pybind11.h>
#include <omp.h>

namespace aco {

AntColony::AntColony(
  common::Hyperparams _hyperparams,
  std::vector<common::Exam> _exams,
  std::vector<int64_t> _slot_timestamps,
  std::vector<common::Room> _rooms,
  int64_t _base_seed
) : hyperparams(_hyperparams),
    problem_data(std::move(_exams), std::move(_slot_timestamps), std::move(_rooms)),
    evaluator(problem_data, hyperparams),
    base_seed(_base_seed),
    pheromone(problem_data.num_exams, problem_data.num_slots, hyperparams.aco.tau_max()),
    global_best_schedule(problem_data.num_exams, -1),
    global_best_fitness(HARD_CONSTRAINT_PENALTY)
{
  PANIC_IF(_base_seed < -1, "base_seed must be -1 or non-negative (got: {})", _base_seed);
  rngs.reserve(hyperparams.aco.num_ants());
  for (int i = 0; i < hyperparams.aco.num_ants(); ++i) {
    std::seed_seq seq {
      static_cast<uint32_t>(base_seed),
      static_cast<uint32_t>(base_seed >> 32),
      static_cast<uint32_t>(i),
      0x9e3779b9u  // golden-ratio constant for seed mixing
    };
    rngs.emplace_back(seq);
  }
  ants.reserve(hyperparams.aco.num_ants());
  for (int i = 0; i < hyperparams.aco.num_ants(); ++i) {
    ants.emplace_back(problem_data);
  }
}

bool AntColony::construct_ant(common::Solution& ant, std::mt19937& rng) {
  static thread_local std::vector<double> weights;
  static thread_local std::vector<double> delta_soft;
  ant.reset();
  weights.resize(problem_data.num_slots);
  delta_soft.resize(problem_data.num_slots);

  for (int i = 0; i < problem_data.num_exams; ++i) {
    const int exam = ant.get_next_exam(problem_data);

    // Check if the solution is infeasible --> ant die now
    const int count_feasible = ant.feasible_slots.get_feasible_count(exam);
    if (count_feasible == 0) {
      ant.fitness = HARD_CONSTRAINT_PENALTY;
      return false;
    }

    // For each feasible slot, calculate penalty if we assign this exam to that slot
    double total_weight = 0.0;
    for (int j = 0; j < count_feasible; ++j) {
      const int slot = ant.feasible_slots(exam, j);
      delta_soft[j] = evaluator.calculate_delta_penalty(ant.assigned_slots, exam, slot);
      const double eta = 1.0 / (1.0 + delta_soft[j]);
      const double tau = pheromone(exam, slot);
      weights[j] = std::pow(tau, hyperparams.aco.alpha()) * std::pow(eta, hyperparams.aco.beta());
      total_weight += weights[j];
    }

    // Choose a random slot using Stochastic Propotional Rule (roulette wheel)
    total_weight = std::max(total_weight, 1e-9);
    const double threshold = std::uniform_real_distribution<double>(0.0, total_weight)(rng);
    double cumulative = 0.0;
    int chosen_j = count_feasible - 1;
    for (int j = 0; j < count_feasible; ++j) {
      cumulative += weights[j];
      if (cumulative >= threshold) {
        chosen_j = j;
        break;
      }
    }

    const int slot = ant.feasible_slots(exam, chosen_j);
    const double penalty = delta_soft[chosen_j];
    ant.assign_exam(exam, slot, problem_data.conflicts_csrmatrix);
    ant.fitness += penalty;
  }
  return true;
}

void AntColony::update_pheromone(const std::vector<int>& best_schedule) {
  for (int exam = 0; exam < problem_data.num_exams; ++exam) {
    const int assigned_slot = best_schedule[exam];
    for (int slot = 0; slot < problem_data.num_slots; ++slot) {
      const double delta_tau = slot == assigned_slot
          ? hyperparams.aco.rho() * hyperparams.aco.tau_max()
          : hyperparams.aco.rho() * hyperparams.aco.tau_min();
      pheromone(exam, slot) = (1.0 - hyperparams.aco.rho()) * pheromone(exam, slot) + delta_tau;
    }
  }
}

double AntColony::run_one_iteration() {
  #pragma omp parallel for schedule(dynamic)
  for (int i = 0; i < hyperparams.aco.num_ants(); ++i) {
    bool ok = false;
    for (int t = 0; !ok && t < 100; ++t) {
      ok = construct_ant(ants[i], rngs[i]);
    }
    if (ok) {
      local_search(ants[i], rngs[i]);
    }
  }

  const common::Solution& iter_best = *std::min_element(ants.begin(), ants.end());
  if (iter_best.fitness >= HARD_CONSTRAINT_PENALTY) {
    return iter_best.fitness;
  }
  if (iter_best.fitness < global_best_fitness) {
    global_best_fitness = iter_best.fitness;
    global_best_schedule = iter_best.assigned_slots;
  }
  update_pheromone(iter_best.assigned_slots);
  return iter_best.fitness;
}

void AntColony::run(std::function<void(int, double)> callback) {
  pybind11::gil_scoped_release release;
  for (int iter = 1; iter <= hyperparams.aco.num_iters(); ++iter) {
    const double iter_best_cost = run_one_iteration();
    if (callback) {
      pybind11::gil_scoped_acquire acquire;
      callback(iter, iter_best_cost);
    }
  }
}

} // namespace aco